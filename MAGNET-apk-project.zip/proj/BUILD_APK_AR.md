# بناء APK لـ MAGNET (جاهز)

مجلد android موجود مسبقاً وبه اتجاه أفقي. للحصول على APK بدون Android Studio:

## الطريقة 1: GitHub Actions (الأسهل، من الهاتف)
1. أنشئ مستودعاً جديداً على github.com وارفع محتوى هذا المجلد كاملاً (بما فيه .github و android).
2. افتح تبويب Actions ← Build MAGNET APK ← Run workflow (يعمل تلقائياً عند الرفع).
3. بعد دقائق نزّل MAGNET-apk من قسم Artifacts، وفيه app-debug.apk.

## الطريقة 2: جهاز فيه Android SDK + Java 17
npm install --legacy-peer-deps && npm run build:mobile && npx cap sync android
cd android && ./gradlew assembleDebug
الناتج: android/app/build/outputs/apk/debug/app-debug.apk
