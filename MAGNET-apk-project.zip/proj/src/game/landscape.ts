/** Convert viewport input to the game's clockwise-rotated landscape surface. */
export function gamePoint(x: number, y: number, width: number, height: number) {
  return height > width ? { x: y, y: width - x } : { x, y };
}

export function gameSize(width: number, height: number) {
  return { width: Math.max(width, height), height: Math.min(width, height) };
}