import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { gamePoint, gameSize } from "./landscape";
import heroA from "@/assets/hero.png.asset.json";
import crawlerA from "@/assets/crawler.png.asset.json";
import bgA from "@/assets/hk_bg.jpg.asset.json";
import swordA from "@/assets/sword.png.asset.json";
import beastA from "@/assets/beast.png.asset.json";

type V = { x: number; y: number };
type Rect = { x: number; y: number; w: number; h: number };
type Crate = Rect & { vx: number; vy: number; core: boolean };
type Enemy = Rect & { vx: number; vy: number; hp: number; dir: number; hurt: number; alive: boolean; boss?: boolean; atk?: number };
type P = { x: number; y: number; vx: number; vy: number; life: number; c: string };

const G = 1450, WORLD = 5200, FLOOR = 620;

function makeLevel() {
  const solids: Rect[] = [
    { x: -200, y: FLOOR, w: 1500, h: 400 },
    { x: 1500, y: FLOOR, w: 900, h: 400 },
    { x: 2650, y: FLOOR, w: 1100, h: 400 },
    { x: 3950, y: FLOOR, w: 1400, h: 400 },
    { x: 700, y: 470, w: 220, h: 26 },
    { x: 1950, y: 440, w: 200, h: 26 },
    { x: 3200, y: 420, w: 260, h: 26 },
    { x: 4300, y: 380, w: 300, h: 26 },
    { x: -200, y: -400, w: 200, h: 1500 },
    { x: WORLD, y: -400, w: 200, h: 1500 },
  ];
  const anchors: V[] = [{ x: 1400, y: 300 }, { x: 2520, y: 280 }, { x: 3850, y: 260 }, { x: 4650, y: 220 }];
  const crates: Crate[] = [
    { x: 500, y: 560, w: 56, h: 56, vx: 0, vy: 0, core: true },
    { x: 1100, y: 560, w: 56, h: 56, vx: 0, vy: 0, core: false },
    { x: 2200, y: 560, w: 56, h: 56, vx: 0, vy: 0, core: true },
    { x: 3000, y: 560, w: 56, h: 56, vx: 0, vy: 0, core: true },
    { x: 4200, y: 560, w: 56, h: 56, vx: 0, vy: 0, core: true },
  ];
  const enemies: Enemy[] = [900, 1700, 2100, 2900, 3400, 4100, 4500].map((x) => ({
    x, y: 560, w: 110, h: 60, vx: 0, vy: 0, hp: 3, dir: -1, hurt: 0, alive: true,
  }));
  enemies.push({ x: 4600, y: 420, w: 200, h: 200, vx: 0, vy: 0, hp: 24, dir: -1, hurt: 0, alive: true, boss: true, atk: 2 });
  return { solids, anchors, crates, enemies };
}

const hit = (a: Rect, b: Rect) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

function collide(o: Rect & { vx: number; vy: number }, solids: Rect[], dt: number) {
  let ground = false;
  o.x += o.vx * dt;
  for (const s of solids) if (hit(o, s)) { if (o.vx > 0) o.x = s.x - o.w; else o.x = s.x + s.w; o.vx = 0; }
  o.y += o.vy * dt;
  for (const s of solids) if (hit(o, s)) { if (o.vy > 0) { o.y = s.y - o.h; ground = true; } else o.y = s.y + s.h; o.vy = 0; }
  return ground;
}

export default function MagnetGame() {
  const cv = useRef<HTMLCanvasElement>(null);
  const [state, setState] = useState<"menu" | "play" | "dead" | "win">("menu");
  const [hud, setHud] = useState({ hp: 5, pol: "attract" as "attract" | "repel", kills: 0 });
  const input = useRef({ mx: 0, jump: false, aim: { x: 1, y: 0 }, active: false, pol: 1, slash: false });
  const point = (x: number, y: number) => gamePoint(x, y, window.innerWidth, window.innerHeight);
  const stickL = useRef<{ id: number; ox: number; oy: number } | null>(null);
  const stickR = useRef<{ id: number; ox: number; oy: number } | null>(null);
  const [knobs, setKnobs] = useState({ l: { x: 0, y: 0 }, r: { x: 0, y: 0 } });

  useEffect(() => {
    if (state !== "play") return;
    const c = cv.current; if (!c) return; const ctx = c.getContext("2d"); if (!ctx) return;
    const imgs = [heroA.url, crawlerA.url, bgA.url, swordA.url, beastA.url].map((u) => { const i = new Image(); i.src = u; return i; });
    const [hero, crawler, bg, sword, beast] = imgs as HTMLImageElement[] as [HTMLImageElement, HTMLImageElement, HTMLImageElement, HTMLImageElement, HTMLImageElement];
    const L = makeLevel();
    const pl = { x: 120, y: 500, w: 34, h: 92, vx: 0, vy: 0, face: 1, ground: false, hp: 5, inv: 0, walk: 0, atk: 0, cd: 0, combo: 0, land: 0, wasGround: false, active: false, coyote: 0, jumpBuffer: 0 };
    let shake = 0;
    const parts: P[] = [];
    const blade = { x: pl.x + 30, y: pl.y + 38, vx: 0, vy: 0, active: false, returning: false, travelled: 0, hit: new Set<Enemy>() };
    let cam = 0, kills = 0, raf = 0, last = performance.now(), done = false;
    const goal: Rect = { x: 5000, y: 520, w: 60, h: 100 };
    let ac: AudioContext | null = null, osc: OscillatorNode | null = null, gain: GainNode | null = null;
    try { ac = new AudioContext(); osc = ac.createOscillator(); gain = ac.createGain(); osc.type = "sawtooth"; gain.gain.value = 0; const f = ac.createBiquadFilter(); f.frequency.value = 500; osc.connect(f); f.connect(gain); gain.connect(ac.destination); osc.start(); } catch { /* no audio */ }
    const thud = (fr: number) => { if (!ac) return; const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = fr; o.frequency.exponentialRampToValueAtTime(40, ac.currentTime + 0.2); g.gain.value = 0.25; g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + 0.25); o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime + 0.3); };

    const keys = new Set<string>();
    const kd = (e: KeyboardEvent) => { keys.add(e.key.toLowerCase()); if (e.key.toLowerCase() === "q") input.current.pol *= -1; if (e.key.toLowerCase() === "j" || e.key.toLowerCase() === "f") input.current.slash = true; };
    const ku = (e: KeyboardEvent) => keys.delete(e.key.toLowerCase());
    const mm = (e: MouseEvent) => { const p = point(e.clientX, e.clientY); const size = gameSize(window.innerWidth, window.innerHeight); const scale = c.height / size.height; const dx = p.x * scale + cam - (pl.x + 17), dy = p.y * scale - (pl.y + 40); const m = Math.hypot(dx, dy) || 1; input.current.aim = { x: dx / m, y: dy / m }; };
    const md = (e: MouseEvent) => { if (e.target === c) { mm(e); if (e.button === 2) input.current.slash = true; else input.current.active = true; } };
    c.oncontextmenu = (e) => e.preventDefault();
    c.style.touchAction = "none";
    const mu = () => { if (!stickR.current) input.current.active = false; };
    window.addEventListener("keydown", kd); window.addEventListener("keyup", ku);
    c.addEventListener("mousemove", mm); c.addEventListener("mousedown", md); window.addEventListener("mouseup", mu);

    const spark = (x: number, y: number, col: string, n = 6) => { for (let i = 0; i < n; i++) parts.push({ x, y, vx: (Math.random() - .5) * 300, vy: (Math.random() - .5) * 300, life: .6, c: col }); };

    const step = (dt: number) => {
      const I = input.current;
      let mx = I.mx; if (keys.has("a") || keys.has("arrowleft")) mx = -1; if (keys.has("d") || keys.has("arrowright")) mx = 1;
      const jump = I.jump || keys.has(" ") || keys.has("w") || keys.has("arrowup");
      if (jump) pl.jumpBuffer = .13; else pl.jumpBuffer = Math.max(0, pl.jumpBuffer - dt);
      if (pl.ground) pl.coyote = .11; else pl.coyote = Math.max(0, pl.coyote - dt);
      const active = I.active || keys.has("e");
      pl.vx += (mx * 390 - pl.vx) * Math.min(1, dt * (pl.ground ? 15 : 5));
      if (mx) pl.face = mx > 0 ? 1 : -1;
      if (pl.jumpBuffer > 0 && pl.coyote > 0) { pl.vy = -650; pl.ground = false; pl.coyote = 0; pl.jumpBuffer = 0; thud(240); }
      pl.vy += G * dt;
      pl.active = active; pl.cd -= dt;
      if (I.slash) {
        I.slash = false;
        if (!blade.active && pl.cd <= 0 && I.pol < 0) {
          blade.x = pl.x + 17 + I.aim.x * 38; blade.y = pl.y + 40 + I.aim.y * 20;
          blade.vx = I.aim.x * 1050; blade.vy = I.aim.y * 1050;
          blade.active = true; blade.returning = false; blade.travelled = 0; blade.hit.clear();
          pl.cd = .42; thud(420);
        } else if (!blade.active && pl.cd <= 0) {
          pl.atk = .28; pl.cd = .34; pl.combo ^= 1; pl.vx += pl.face * 100; thud(320);
        }
      }
      if (pl.atk > 0) {
        const prev = pl.atk; pl.atk -= dt;
        if (prev > .16 && pl.atk <= .16) {
          const box = { x: pl.face > 0 ? pl.x + 12 : pl.x - 112, y: pl.y - 2, w: 124, h: 100 };
          for (const e of L.enemies) if (e.alive && hit(box, e)) { e.hp -= 1.5; e.hurt = .3; e.vx = pl.face * (e.boss ? 100 : 430); e.vy = e.boss ? -50 : -230; spark(e.x + e.w / 2, e.y + e.h / 2, "#ffe2b0", 18); thud(120); shake = .14; }
          for (const b of L.crates) if (hit(box, b)) { b.vx = pl.face * 600; b.vy = -220; }
        }
      }
      if (blade.active) {
        const px = pl.x + 17, py = pl.y + 40;
        if (I.pol > 0 || blade.travelled > 720) blade.returning = true;
        if (blade.returning) {
          const dx = px - blade.x, dy = py - blade.y, d = Math.hypot(dx, dy) || 1;
          blade.vx += (dx / d * 1320 - blade.vx) * Math.min(1, dt * 7);
          blade.vy += (dy / d * 1320 - blade.vy) * Math.min(1, dt * 7);
          if (d < 38) { blade.active = false; blade.returning = false; spark(px, py, "#8cecff", 8); }
        } else { blade.vx += (I.aim.x * 1050 - blade.vx) * Math.min(1, dt * 4); blade.vy += (I.aim.y * 1050 - blade.vy) * Math.min(1, dt * 4); }
        if (blade.active) {
          blade.x += blade.vx * dt; blade.y += blade.vy * dt; blade.travelled += Math.hypot(blade.vx, blade.vy) * dt;
          for (const e of L.enemies) if (e.alive && !blade.hit.has(e) && hit({ x: blade.x - 25, y: blade.y - 12, w: 50, h: 24 }, e)) {
            blade.hit.add(e); e.hp -= 2; e.hurt = .35; e.vx += Math.sign(blade.vx) * (e.boss ? 100 : 250); e.vy = -180;
            spark(blade.x, blade.y, "#9cecff", 18); thud(105); shake = .12;
          }
        }
      }      const col = I.pol > 0 ? "rgba(90,220,255," : "rgba(255,110,60,";
      if (active) {
        const ax = pl.x + 17, ay = pl.y + 40, R = 420;
        const inCone = (x: number, y: number) => { const dx = x - ax, dy = y - ay, d = Math.hypot(dx, dy); return d < R && d > 1 && (dx * I.aim.x + dy * I.aim.y) / d > 0.82 ? d : 0; };
        for (const a of L.anchors) { const d = inCone(a.x, a.y); if (d) { const k = I.pol * 1550 / Math.max(d, 100); pl.vx += ((a.x - ax) / d) * k * dt; pl.vy += ((a.y - ay) / d) * k * dt - (I.pol > 0 ? G * dt * .7 : 0); } }
        for (const b of L.crates) { const d = inCone(b.x + 28, b.y + 28); if (!d) continue; if (I.pol < 0 && !b.core) continue; const f = (I.pol > 0 ? -1 : 1) * 1350 * dt; b.vx += ((b.x + 28 - ax) / d) * f; b.vy += ((b.y + 28 - ay) / d) * f - (I.pol > 0 ? G * dt : 0); if (I.pol > 0 && d < 60) { b.vx *= .8; b.vy *= .8; } }
        for (const e of L.enemies) { if (!e.alive) continue; const d = inCone(e.x + e.w / 2, e.y + e.h / 2); if (!d) continue; const f = (I.pol > 0 ? -1 : 1) * (e.boss ? 220 : 1050) * dt; e.vx += ((e.x + 55 - ax) / d) * f; e.vy += ((e.y + 30 - ay) / d) * f * .6; if (I.pol < 0 && d < 140 && e.hurt <= 0) { e.hp--; e.hurt = .4; e.vy = -400; spark(e.x + 55, e.y + 30, "#ff7a3c", 14); thud(160); } }
        for (let i = 0; i < 3; i++) { const t = Math.random(), sp = (Math.random() - .5) * .5; const cs = Math.cos(sp), sn = Math.sin(sp); const dx = I.aim.x * cs - I.aim.y * sn, dy = I.aim.x * sn + I.aim.y * cs; const dist = I.pol > 0 ? R * (1 - t) : R * t * .3; parts.push({ x: ax + dx * dist, y: ay + dy * dist, vx: -I.pol * dx * 500, vy: -I.pol * dy * 500, life: .5, c: col + "0.9)" }); }
      }
      if (gain && ac && osc) gain.gain.setTargetAtTime(active ? .05 : 0, ac.currentTime, .05), osc.frequency.setTargetAtTime(I.pol > 0 ? 70 : 110, ac.currentTime, .05);
      pl.vx = Math.max(-650, Math.min(650, pl.vx)); pl.vy = Math.max(-1000, Math.min(1100, pl.vy));
      pl.wasGround = pl.ground; pl.ground = collide(pl, L.solids, dt); if (pl.ground && !pl.wasGround) pl.land = .15; pl.land -= dt;
      if (Math.abs(pl.vx) > 24 && pl.ground) pl.walk += dt * Math.abs(pl.vx) / 34;
      if (pl.y > 1100) pl.hp = 0;
      for (const b of L.crates) {
        b.vy += G * dt; const g2 = collide(b, L.solids, dt); if (g2) b.vx *= .9;
        const sp = Math.hypot(b.vx, b.vy);
        for (const e of L.enemies) if (e.alive && sp > 380 && !e.boss && hit(b, e) && e.hurt <= 0) { e.hp -= 2; e.hurt = .4; e.vx = b.vx * .6; e.vy = -300; spark(e.x + 55, e.y + 30, "#ffd28a", 18); thud(90); b.vx *= -.3; }
      }
      for (const e of L.enemies) {
        if (!e.alive) continue; e.hurt -= dt;
        if (e.hp <= 0) { e.alive = false; kills++; spark(e.x + 55, e.y + 30, "#ff4020", 30); thud(60); continue; }
        const dx = pl.x - (e.x + e.w / 2); if (Math.abs(dx) < 700) e.dir = Math.sign(dx);
        if (e.boss) { e.atk = (e.atk ?? 2) - dt; if (Math.abs(dx) < 800) { if (e.atk < 0) { e.vx = e.dir * 620; e.vy = -420; e.atk = 2.4; shake = .3; } else if (e.hurt <= 0) e.vx += (e.dir * 70 - e.vx) * dt * 2; } }
        else if (e.hurt <= 0) e.vx += (e.dir * 150 - e.vx) * dt * 3;
        e.vy += G * dt; collide(e, L.solids, dt); if (e.y > 1100) e.alive = false;
        if (pl.inv <= 0 && hit(pl, { x: e.x + e.w * .14, y: e.y + e.h * .15, w: e.w * .72, h: e.h * .8 })) { pl.hp--; pl.inv = 1.2; pl.vx = -e.dir * -1 * 0 + (pl.x < e.x ? -420 : 420); pl.vy = -380; spark(pl.x + 17, pl.y + 40, "#ddd", 12); thud(200); }
      }
      pl.inv -= dt;
      for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; if (!p) continue; p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt; if (p.life <= 0) parts.splice(i, 1); }
      cam += (pl.x - c.width * .38 - cam) * Math.min(1, dt * 5); cam = Math.max(0, Math.min(WORLD - c.width, cam));
      shake -= dt;
      if (hit(pl, goal) && !L.enemies.some((e) => e.boss && e.alive)) { done = true; setState("win"); }
      if (pl.hp <= 0) { done = true; setState("dead"); }
      setHud((h) => (h.hp !== pl.hp || h.kills !== kills || (h.pol === "attract") !== (I.pol > 0) ? { hp: pl.hp, kills, pol: I.pol > 0 ? "attract" : "repel" } : h));
    };

    const draw = (t: number) => {
      const W = c.width, H = c.height;
      ctx.fillStyle = "#05070d"; ctx.fillRect(0, 0, W, H);
      if (bg.complete && bg.naturalWidth) { const bh = H, bw = bg.naturalWidth * bh / bg.naturalHeight; const off = -(cam * .25) % bw; for (let x = off - bw; x < W; x += bw) { ctx.drawImage(bg, x, 0, bw + 1, bh); ctx.save(); ctx.translate(x + bw * 2, 0); ctx.scale(-1, 1); ctx.restore(); } }
      ctx.fillStyle = "rgba(140,190,255,.35)"; for (let i = 0; i < 40; i++) { const px = ((i * 197 + t * .02 * (1 + i % 3)) - cam * .5) % W, py = (i * 83 + Math.sin(t / 900 + i) * 30) % H; ctx.fillRect((px + W) % W, py, 2, 2); }
      const fog = ctx.createLinearGradient(0, H * .5, 0, H); fog.addColorStop(0, "rgba(6,10,20,0)"); fog.addColorStop(1, "rgba(6,10,20,.8)"); ctx.fillStyle = fog; ctx.fillRect(0, 0, W, H);
      ctx.save(); ctx.translate(-cam + (shake > 0 ? (Math.random() - .5) * 14 : 0), shake > 0 ? (Math.random() - .5) * 10 : 0);
      for (const s of L.solids) { const g = ctx.createLinearGradient(0, s.y, 0, s.y + Math.min(s.h, 120)); g.addColorStop(0, "#2a3346"); g.addColorStop(.15, "#11151f"); g.addColorStop(1, "#04050a"); ctx.fillStyle = g; ctx.fillRect(s.x, s.y, s.w, s.h); ctx.fillStyle = "#8fa6c8"; ctx.fillRect(s.x, s.y, s.w, 2); ctx.fillStyle = "rgba(0,0,0,.5)"; for (let x = s.x + 20; x < s.x + s.w; x += 60) ctx.fillRect(x, s.y + 6, 3, 8); }
      for (const a of L.anchors) { const pulse = 8 + Math.sin(t / 300) * 3; ctx.strokeStyle = "#5a4630"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(a.x, a.y - 300); ctx.lineTo(a.x, a.y - 22); ctx.stroke(); ctx.fillStyle = "#2a2018"; ctx.beginPath(); ctx.arc(a.x, a.y, 22, 0, 7); ctx.fill(); ctx.strokeStyle = "#b08a58"; ctx.stroke(); ctx.shadowColor = "#5ad8ff"; ctx.shadowBlur = 20; ctx.fillStyle = "#5ad8ff"; ctx.beginPath(); ctx.arc(a.x, a.y, pulse, 0, 7); ctx.fill(); ctx.shadowBlur = 0; }
      for (const b of L.crates) { ctx.fillStyle = "#2b241c"; ctx.fillRect(b.x, b.y, b.w, b.h); ctx.strokeStyle = "#7d6040"; ctx.lineWidth = 3; ctx.strokeRect(b.x + 2, b.y + 2, b.w - 4, b.h - 4); ctx.beginPath(); ctx.moveTo(b.x + 4, b.y + 4); ctx.lineTo(b.x + b.w - 4, b.y + b.h - 4); ctx.stroke(); if (b.core) { ctx.shadowColor = "#ff6a3a"; ctx.shadowBlur = 16; ctx.fillStyle = "#ff6a3a"; ctx.fillRect(b.x + 22, b.y + 22, 12, 12); ctx.shadowBlur = 0; } }
      ctx.save(); ctx.shadowColor = "#7ae8ff"; ctx.shadowBlur = 40; ctx.fillStyle = "#3a2e22"; ctx.fillRect(goal.x, goal.y + 40, goal.w, 60); ctx.fillStyle = "#9af0ff"; ctx.beginPath(); ctx.moveTo(goal.x + 30, goal.y + Math.sin(t / 400) * 6); ctx.lineTo(goal.x + 48, goal.y + 30); ctx.lineTo(goal.x + 30, goal.y + 46); ctx.lineTo(goal.x + 12, goal.y + 30); ctx.fill(); ctx.restore();
      for (const e of L.enemies) { if (!e.alive || !e.boss) continue; ctx.save(); ctx.translate(e.x + e.w / 2, e.y + e.h); const br = Math.sin(t / 280) * .03; ctx.scale((e.dir > 0 ? -1 : 1) * (1 + br), 1 - br); if (e.hurt > 0) ctx.filter = "brightness(2.2)"; ctx.drawImage(beast, -150, -290, 300, 297); ctx.restore();
        ctx.fillStyle = "rgba(0,0,0,.6)"; ctx.fillRect(e.x, e.y - 110, e.w, 8); ctx.fillStyle = "#ff3a2a"; ctx.fillRect(e.x, e.y - 110, e.w * Math.max(0, e.hp) / 24, 8); }
      for (const e of L.enemies) { if (!e.alive || e.boss) continue; ctx.save(); ctx.translate(e.x + 55, e.y + 30 + Math.sin(t / 60 + e.x) * 1.5); ctx.scale(e.dir > 0 ? -1 : 1, 1); if (e.hurt > 0) ctx.filter = "brightness(2.2)"; ctx.drawImage(crawler, -70, -50, 140, 84); ctx.restore(); }
      { const moving = Math.abs(pl.vx) > 30 && pl.ground; const bob = moving ? Math.abs(Math.sin(pl.walk)) * 5 : Math.sin(t / 500) * 1.5;
        let sx = 1, sy = 1; if (!pl.ground) { const k = Math.min(.12, Math.abs(pl.vy) / 6000); sx = 1 - k; sy = 1 + k; } if (pl.land > 0) { sx = 1.12; sy = .88; }
        const atkP = pl.atk > 0 ? 1 - pl.atk / .3 : -1; const lean = moving ? pl.vx / 340 * .1 : 0;
        ctx.save(); ctx.translate(pl.x + 17, pl.y + pl.h); ctx.scale(pl.face, 1);
        if (pl.inv > 0 && Math.floor(t / 80) % 2) ctx.globalAlpha = .4;
        ctx.save(); ctx.scale(sx, sy); ctx.rotate(lean + (atkP >= 0 ? Math.sin(atkP * Math.PI) * .18 : 0) + (pl.ground ? 0 : pl.vy * .00008)); ctx.drawImage(hero, -42, -128 - bob, 84, 132); ctx.restore();
        // Sword stays attached during melee; the thrown blade is rendered in world space below.
        const hx = 14, hy = -70 - bob; let ang: number;
        if (atkP >= 0) { const e2 = 1 - Math.pow(1 - atkP, 3); ang = pl.combo ? -2.3 + e2 * 3.3 : 1.3 - e2 * 3.4; }
        else ang = -2.4 + Math.sin(pl.walk) * (moving ? .15 : .03) + Math.sin(t / 500) * .03;
        if (atkP >= 0 && atkP < .8) { ctx.save(); ctx.globalCompositeOperation = "lighter"; const a0 = pl.combo ? -2.3 : 1.3, a1 = ang; for (let k = 0; k < 6; k++) { ctx.globalAlpha = (1 - atkP) * (.5 - k * .07); ctx.strokeStyle = k < 2 ? "#ffffff" : "#ff6a4a"; ctx.lineWidth = 14 - k * 2; ctx.beginPath(); ctx.arc(hx, hy, 96 - k * 9, Math.min(a0, a1), Math.max(a0, a1)); ctx.stroke(); } ctx.restore(); }
        if (!blade.active) { ctx.save(); ctx.translate(hx, hy); ctx.rotate(ang); ctx.shadowColor = "#ff3a3a"; ctx.shadowBlur = atkP >= 0 ? 24 : 8; ctx.drawImage(sword, -22, -16, 110, 33); ctx.restore(); }
        ctx.restore(); }
      if (blade.active) { ctx.save(); ctx.translate(blade.x, blade.y); ctx.rotate(Math.atan2(blade.vy, blade.vx)); ctx.shadowColor = blade.returning ? "#72e8ff" : "#ff7656"; ctx.shadowBlur = 24; ctx.drawImage(sword, -42, -13, 84, 26); ctx.restore(); }
      if (pl.active) { const ax = pl.x + 17, ay = pl.y + 40, ang = Math.atan2(input.current.aim.y, input.current.aim.x), blue = input.current.pol > 0; const c1 = blue ? "90,220,255" : "255,80,50", c2 = blue ? "200,250,255" : "255,210,170";
        ctx.save(); ctx.translate(ax, ay); ctx.rotate(ang); ctx.globalCompositeOperation = "lighter";
        const flow = (t / (blue ? -4 : 4)) % 420;
        for (let k = 0; k < 9; k++) { const len = 380 + Math.sin(t / 90 + k) * 40, sp = (k - 4) * 6 + Math.sin(t / 70 + k * 2) * 8; ctx.strokeStyle = `rgba(${k % 3 ? c1 : c2},${.25 + (k % 3 ? 0 : .35)})`; ctx.lineWidth = k % 3 ? 2 : 3.5; ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(len * .5, sp * 1.5 + Math.sin(t / 50 + k) * 6, len, sp * .3); ctx.stroke(); }
        const gr = ctx.createLinearGradient(0, 0, 400, 0); gr.addColorStop(0, `rgba(${c2},.9)`); gr.addColorStop(.5, `rgba(${c1},.35)`); gr.addColorStop(1, `rgba(${c1},0)`); ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(0, -6); ctx.lineTo(400, -1); ctx.lineTo(400, 1); ctx.lineTo(0, 6); ctx.fill();
        for (let k = 0; k < 4; k++) { const d = ((flow + k * 105) % 420 + 420) % 420; ctx.strokeStyle = `rgba(${c1},${.6 * (1 - d / 420)})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(d, 0, 6 + d * .02, 10 + d * .14, 0, 0, Math.PI * 2); ctx.stroke(); }
        ctx.shadowColor = `rgb(${c1})`; ctx.shadowBlur = 30; ctx.fillStyle = `rgba(${c2},.9)`; ctx.beginPath(); ctx.arc(0, 0, 9 + Math.sin(t / 40) * 3, 0, 7); ctx.fill();
        ctx.restore(); }
      ctx.globalCompositeOperation = "lighter"; for (const p of parts) { ctx.globalAlpha = Math.max(0, p.life * 1.6); ctx.fillStyle = p.c; ctx.fillRect(p.x, p.y, 3, 3); } ctx.globalAlpha = 1; ctx.globalCompositeOperation = "source-over";
      ctx.restore();
      const vg = ctx.createRadialGradient(W / 2, H / 2, H * .3, W / 2, H / 2, W * .7); vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, "rgba(0,0,0,.7)"); ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
    };

    const loop = (now: number) => {
      const dt = Math.min(.033, (now - last) / 1000); last = now;
      const H = 760, W = Math.round(H * c.clientWidth / c.clientHeight); if (c.width !== W || c.height !== H) { c.width = W; c.height = H; }
      if (!done) step(dt); draw(now); if (!done) raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("keydown", kd); window.removeEventListener("keyup", ku); window.removeEventListener("mouseup", mu); c.removeEventListener("mousemove", mm); c.removeEventListener("mousedown", md); ac?.close(); };
  }, [state]);

  const touchStick = (side: "l" | "r") => ({
    onTouchStart: (e: React.TouchEvent) => { const t = e.changedTouches[0]; if (!t) return; const p = point(t.clientX, t.clientY); (side === "l" ? stickL : stickR).current = { id: t.identifier, ox: p.x, oy: p.y }; if (side === "r") input.current.active = true; },
    onTouchMove: (e: React.TouchEvent) => { const s = (side === "l" ? stickL : stickR).current; if (!s) return; for (const t of Array.from(e.changedTouches)) if (t.identifier === s.id) { const p = point(t.clientX, t.clientY); let dx = p.x - s.ox, dy = p.y - s.oy; const m = Math.hypot(dx, dy); if (m > 45) { dx *= 45 / m; dy *= 45 / m; } setKnobs((k) => ({ ...k, [side]: { x: dx, y: dy } })); if (side === "l") input.current.mx = Math.abs(dx) > 10 ? Math.sign(dx) : 0; else if (m > 8) input.current.aim = { x: dx / Math.hypot(dx, dy), y: dy / Math.hypot(dx, dy) }; } },
    onTouchCancel: () => { (side === "l" ? stickL : stickR).current = null; setKnobs((k) => ({ ...k, [side]: { x: 0, y: 0 } })); if (side === "l") input.current.mx = 0; else input.current.active = false; },
    onTouchEnd: () => { (side === "l" ? stickL : stickR).current = null; setKnobs((k) => ({ ...k, [side]: { x: 0, y: 0 } })); if (side === "l") input.current.mx = 0; else input.current.active = false; },
  });

  const start = () => { input.current = { mx: 0, jump: false, aim: { x: 1, y: 0 }, active: false, pol: 1, slash: false }; setKnobs({ l: { x: 0, y: 0 }, r: { x: 0, y: 0 } }); setHud({ hp: 5, pol: "attract", kills: 0 }); setState("play"); document.documentElement.requestFullscreen?.().catch(() => {}); };
  const polCls = hud.pol === "attract" ? "text-magnet-attract border-magnet-attract" : "text-magnet-repel border-magnet-repel";

  return (
    <div className="magnet-surface select-none overflow-hidden bg-background touch-none">
      <canvas ref={cv} className="absolute inset-0 h-full w-full" />
      {state === "play" && (<>
        <div className="absolute left-4 top-3 flex items-center gap-3 font-display">
          <div className="flex gap-1">{Array.from({ length: 5 }).map((_, i) => <div key={i} className={`h-4 w-3 rotate-45 border border-bronze ${i < hud.hp ? "bg-bone" : "bg-transparent"}`} />)}</div>
          <span className="text-sm text-muted-foreground">✦ {hud.kills}</span>
        </div>
        <Button variant="ghost" onClick={() => (input.current.pol *= -1)} className={`absolute right-4 top-3 rounded border-2 bg-background/60 px-3 py-1 font-display text-sm uppercase ${polCls}`}>{hud.pol === "attract" ? "جذب ⟵" : "تنافر ⟶"}</Button>
        <div {...touchStick("l")} className="absolute bottom-0 left-0 h-1/2 w-1/3">
          <div className="absolute bottom-8 left-8 h-28 w-28 rounded-full border-2 border-bronze/50 bg-background/30"><div className="absolute left-1/2 top-1/2 h-12 w-12 -translate-x-1/2 -translate-y-1/2 rounded-full bg-bronze/70" style={{ transform: `translate(calc(-50% + ${knobs.l.x}px), calc(-50% + ${knobs.l.y}px))` }} /></div>
        </div>
        <div {...touchStick("r")} className="absolute bottom-0 right-0 h-1/2 w-1/3">
          <div className={`absolute bottom-8 right-8 h-28 w-28 rounded-full border-2 bg-background/30 ${polCls}`}><div className="absolute left-1/2 top-1/2 h-12 w-12 rounded-full bg-current opacity-60" style={{ transform: `translate(calc(-50% + ${knobs.r.x}px), calc(-50% + ${knobs.r.y}px))` }} /></div>
        </div>
        <Button variant="ghost" onTouchStart={() => (input.current.jump = true)} onTouchEnd={() => (input.current.jump = false)} onMouseDown={() => (input.current.jump = true)} onMouseUp={() => (input.current.jump = false)} className="absolute bottom-40 right-44 h-16 w-16 rounded-full border-2 border-bone/60 bg-background/40 font-display text-xs text-bone">قفز</Button>
        <Button variant="ghost" onTouchStart={() => (input.current.slash = true)} onMouseDown={() => (input.current.slash = true)} className="absolute bottom-24 right-64 h-16 w-16 rounded-full border-2 border-magnet-repel/70 bg-background/40 font-display text-xs text-bone">سيف</Button>
      </>)}
      {state !== "play" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-background/80 p-6 text-center" dir="rtl">
          <h1 className="font-display text-5xl text-bone">MAGNET</h1>
          <p className="max-w-md text-sm text-muted-foreground">
            {state === "menu" && "انزل إلى أعماق المجمّع واستعد مكوّن الطاقة لمستوطنتك. استخدم القفاز لجذب المعادن أو صدّها، وارمِ سيفك في وضع التنافر ثم بدّل إلى الجذب ليعود ممزقاً طريقه عبر الأعداء."}
            {state === "dead" && "سقطتَ في ظلام المجمّع..."}
            {state === "win" && `استعدتَ مكوّن الطاقة! كائنات مهزومة: ${hud.kills}`}
          </p>
          <Button variant="ghost" onClick={start} className="h-auto rounded border-2 border-bronze bg-secondary px-8 py-3 font-display text-lg uppercase text-bone">{state === "menu" ? "ابدأ" : "مرة أخرى"}</Button>
          <p className="max-w-md text-xs text-muted-foreground">الهاتف: العصا اليسرى للحركة، العصا اليمنى للتصويب مع الاستمرار لتفعيل القفاز، زر القطبية للتبديل، وزرا القفز ورمي السيف. ارمِ السيف بالتنافر وأعده بالجذب. <br />الحاسوب: A/D حركة، Space قفز، استمر بزر الفأرة لتفعيل القفاز، Q تبديل القطبية، وJ لرمي السيف أو تنفيذ ضربة قريبة.</p>
        </div>
      )}
    </div>
  );
}
