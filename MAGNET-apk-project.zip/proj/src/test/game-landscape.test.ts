import { describe, expect, it } from "vitest";
import { gamePoint, gameSize } from "@/game/landscape";

describe("Landscape game without phone rotation", () => {
  it("keeps a horizontal playfield on a portrait phone", () => {
    expect(gameSize(338, 620)).toEqual({ width: 620, height: 338 });
    expect(gameSize(620, 338)).toEqual({ width: 620, height: 338 });
  });
  it("maps portrait gestures onto landscape movement and aiming", () => {
    expect(gamePoint(300, 100, 338, 620)).toEqual({ x: 100, y: 38 });
    expect(gamePoint(300, 145, 338, 620)).toEqual({ x: 145, y: 38 });
    expect(gamePoint(255, 100, 338, 620)).toEqual({ x: 100, y: 83 });
    expect(gamePoint(100, 38, 620, 338)).toEqual({ x: 100, y: 38 });
  });
});