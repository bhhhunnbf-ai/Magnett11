import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@tanstack/react-router";
import MagnetGame from "@/game/MagnetGame";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MAGNET — Dark Fantasy Magnetic Adventure" },
      { name: "description", content: "A dark fantasy 2D action game: wield a magnetic gauntlet deep inside The Complex." },
      { property: "og:title", content: "MAGNET — Dark Fantasy Magnetic Adventure" },
      { property: "og:description", content: "Pull and repel metal to fight strange creatures in an underground machine world." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <ClientOnly fallback={null}><MagnetGame /></ClientOnly>,
});
