import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.magnet.game",
  appName: "MAGNET",
  webDir: "dist-mobile",
  bundledWebRuntime: false,
  backgroundColor: "#05070d",
  android: {
    allowMixedContent: false,
  },
};

export default config;
