import React from "react";
import ReactDOM from "react-dom/client";
import MagnetGame from "../src/game/MagnetGame";
import "../src/styles.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <MagnetGame />
  </React.StrictMode>,
);
