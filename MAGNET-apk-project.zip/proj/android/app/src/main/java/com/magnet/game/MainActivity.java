package com.magnet.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
